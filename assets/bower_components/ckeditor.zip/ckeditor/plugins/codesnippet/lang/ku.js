﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","ku",{button:"تێخستنی تیتکی کۆد",codeContents:"ناوەڕۆکی کۆد",emptySnippetError:"تیتکی کۆد نابێت بەتاڵ بێت.",language:"زمان",title:"تیتکی کۆد",pathName:"تیتکی کۆد"});